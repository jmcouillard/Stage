import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

import processing.core.PApplet;
import processing.video.Movie;
import stage.display.Sprite;
import stage.display.Stage;

public class StageTest extends PApplet implements WindowFocusListener {

	private static final long serialVersionUID = 1;

	public static final int WIDTH = 960;
	public static final int HEIGHT = 540;

	public static int screenWidth = WIDTH;
	public static int screenHeight = HEIGHT;

	public Stage stage;
	public Sprite layer;

	public void setup() {

		// Setup
		size(screenWidth, screenHeight, OPENGL);
		hint(ENABLE_OPENGL_ERRORS);
		hint(DISABLE_TEXTURE_MIPMAPS);

		// Focus listener
		frame.addWindowFocusListener(this);

		// New stage
		stage = new Stage(this, width, height);

		// Init Sprite
		layer = new Sprite(this, 200, 200);
		layer.setX(200);
		layer.setY(200);
		layer.centerAnchor();
		layer.graphic.beginDraw();
		layer.graphic.fill(0xFFFF0000);
		layer.graphic.rect(0, 0, 200, 200);
		layer.graphic.endDraw();
		stage.addChild(layer);
	}

	public void draw() {

		stage.update();
		stage.draw(this);

		// Update FPS count in the title bar
		if (frameCount % 30 == 1) {
			this.frame.setTitle("Stage Test " + " (" + Math.round(frameRate) + "fps)");
		}
	}

	public void windowGainedFocus(WindowEvent e) {
		println("WindowFocusListener method called: windowGainedFocus.");
	}

	public void windowLostFocus(WindowEvent e) {
		println("WindowFocusListener method called: windowLostFocus.");
	}

	public void mouseMoved() {
		super.mouseMoved();
	}

	public void keyPressed() {
		super.keyPressed();
	}

	public void mousePressed() {
		super.mousePressed();
	}

	public void movieEvent(Movie m) {
		m.read();
	}

	public static void main(String[] args) {
		PApplet.main(new String[] { "--bgcolor=#000000", StageTest.class.getName() });

	}

}
